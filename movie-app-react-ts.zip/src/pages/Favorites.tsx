
import { useEffect, useState } from "react";
import { getFavorites, removeFavorite } from "../utils/favorites";

export default function Favorites() {
  const [movies, setMovies] = useState([]);

  useEffect(() => {
    setMovies(getFavorites());
  }, []);

  const remove = (id:number) => {
    removeFavorite(id);
    setMovies(getFavorites());
  };

  return (
    <div className="grid">
      {movies.map((m:any) => (
        <div key={m.id} className="card">
          <img width="100%" src={`https://image.tmdb.org/t/p/w500${m.poster_path}`} />
          <div style={{ padding: 8 }}>
            <p>{m.title}</p>
            <button onClick={() => remove(m.id)}>Remove</button>
          </div>
        </div>
      ))}
    </div>
  );
}
