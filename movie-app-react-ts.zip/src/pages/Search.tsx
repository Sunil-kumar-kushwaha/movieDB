
import { useState } from "react";
import { searchMovies } from "../api/tmdb";
import MovieCard from "../components/MovieCard";

export default function Search() {
  const [query, setQuery] = useState("");
  const [movies, setMovies] = useState([]);

  const search = async () => {
    const res = await searchMovies(query);
    setMovies(res.data.results);
  };

  return (
    <div style={{ padding: 20 }}>
      <input placeholder="Search movie..." onChange={e => setQuery(e.target.value)} />
      <button onClick={search}>Search</button>

      <div className="grid">
        {movies.map((m:any) => <MovieCard key={m.id} movie={m} />)}
      </div>
    </div>
  );
}
