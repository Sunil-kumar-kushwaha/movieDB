
import { Link } from "react-router-dom";

export default function Navbar() {
  return (
    <div className="navbar">
      <div className="logo">NETMOVIE</div>
      <div>
        <Link to="/">Home</Link> | 
        <Link to="/search"> Search</Link> | 
        <Link to="/favorites"> Favorites</Link>
      </div>
    </div>
  );
}
